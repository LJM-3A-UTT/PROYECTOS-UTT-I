<?php $__env->startSection('content'); ?>

<form action="/ljm_login" method="POST">
    <?php echo csrf_field(); ?>
    <h1>Login</h1>
    <?php echo $__env->make('ljm_layouts.ljm_partials.ljm_messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="form-floating mb-3">
        <input type="text" placeholder="username"  name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        <label for="exampleInputEmail1" class="form-label">Username/ Email address</label>
        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
    </div>
    <div class="form-floating mb-3">
        <input type="password" placeholder="password" name="password" class="form-control" id="exampleInputPassword1">
        <label for="exampleInputPassword1" class="form-label">Password</label>
    </div>
    <div class="mb-3">
        <a href="/ljm_register">Create Acount</a>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ljm_layouts.ljm_auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\TSU-4°A-Sep-Dic\AWS\4A-RegistroLoginLaravel-ljm\resources\views/ljm_auth/ljm_login.blade.php ENDPATH**/ ?>