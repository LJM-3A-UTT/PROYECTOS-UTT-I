<?php $__env->startSection('content'); ?>

<h1>ljm_Home</h1>

    <?php if(auth()->guard()->check()): ?>

    <p>Bienvenido <?php echo e(auth()->user()->name ?? auth()->user()->username); ?>, tienes acceso a la pagina como usuario autenticado</p>

    <p><a href="/ljm_logout">Logout</a></p>
    <?php endif; ?>



    <?php if(auth()->guard()->guest()): ?>

    <p>
        Bienvenido, Estas en la pagina principal, como invitado no autenticado, tendras acceso

        <br>limitado hasta que sean un usuario verificado

        <a href="/ljm_login">Inicia sesion para tener acceso total</a>

        <br> o <br>

        <a href="/ljm_register">Registrate si es tu primera vez</a>

        para ver todo lo que tenemos que ofrecer
    </p>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('ljm_layouts.ljm_app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\TSU-4°A-Sep-Dic\AWS\4A-RegistroLoginLaravel-ljm\resources\views/ljm_home/ljm_index.blade.php ENDPATH**/ ?>