<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C2-S12-L10-2111-RegistroLoginLaravel</title>
    <link rel="stylesheet" href="<?php echo e(url('ljm_assets/css/bootstrap.min.css')); ?>">
    <!-- Add your custom stylesheets here if needed -->
</head>
<body>
    <?php echo $__env->make('ljm_layouts.ljm_partials.ljm_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <script src="<?php echo e(url('ljm_assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Add your custom scripts here if needed -->
</body>
</html>
<?php /**PATH C:\Users\Dell\Desktop\TSU-4°A-Sep-Dic\AWS\4A-RegistroLoginLaravel-ljm\resources\views/ljm_layouts/ljm_app-master.blade.php ENDPATH**/ ?>