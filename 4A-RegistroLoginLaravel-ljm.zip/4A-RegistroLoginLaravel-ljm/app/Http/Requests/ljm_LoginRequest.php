<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Auth\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Factory as ValidationFactory;
class ljm_LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'username'=>'required',
            'password'=>'required',
        ];
    }

    public function getCredential(){
        $ljm_username=$this->get('username');
        if($this->isEmail($ljm_username)){
            return[
                'email'=>$ljm_username,
                'password'=>$this->get('password')
            ];
        }
        return $this->only('username', 'password');
    }

    public function isEmail($ljm_value){
        $ljm_factory=$this->container->make(ValidationFactory::class);
    return $ljm_factory->make(['usernme'=>$ljm_value],['username'=>'email'])->fails();

    }
}
