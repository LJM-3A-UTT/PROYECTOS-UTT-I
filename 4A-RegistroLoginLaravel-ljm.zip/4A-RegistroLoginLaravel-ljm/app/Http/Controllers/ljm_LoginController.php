<?php

namespace App\Http\Controllers;

use App\Http\Requests\ljm_LoginRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;


class ljm_LoginController extends Controller
{
    //

    public function ljm_show(){
        if(Auth::check()){
            return redirect('/ljm_home');
        }
        return view('ljm_auth.ljm_login');
    }

    public function ljm_login(ljm_LoginRequest $ljm_request){

        $ljm_credentials=$ljm_request->getCredential();

        if(!Auth::validate($ljm_credentials)){

            return redirect()->to('/ljm_login')->withErrors('Username or password is incorrect');
        }
        $ljm_user=Auth::getProvider()->retrieveByCredentials($ljm_credentials);

        Auth::login($ljm_user);

        return $this->authenticated($ljm_request,$ljm_user);
    }

    public function authenticated(Request $ljm_request,$ljm_user){
        return redirect('/ljm_home');
    }
}
