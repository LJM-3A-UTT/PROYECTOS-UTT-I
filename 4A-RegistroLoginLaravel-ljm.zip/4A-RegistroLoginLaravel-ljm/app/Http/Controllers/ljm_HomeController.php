<?php

namespace App\Http\Controllers;
use App\Http\Controllers\ljm_RegisterController;
use App\Http\Controllers\ljm_LoginController;
use Illuminate\Http\Request;

class ljm_HomeController extends Controller
{
    //
    public function ljm_index(){
        return view('ljm_home.ljm_index');
    }
}
