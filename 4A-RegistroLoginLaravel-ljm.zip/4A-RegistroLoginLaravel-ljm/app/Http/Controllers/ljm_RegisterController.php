<?php

namespace App\Http\Controllers;

use App\Http\Requests\ljm_RegisterRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ljm_RegisterController extends Controller
{
    public function ljm_show()
    {
        // If the user is already authenticated, redirect to ljm_home
        if (Auth::check()) {
            return redirect('/ljm_home');
        }

        // Otherwise, show the registration page
        return view('ljm_auth.ljm_register');
    }

    public function ljm_register(ljm_RegisterRequest $ljm_request)
    {
        $ljm_user = User::create($ljm_request->validated());
        return redirect('/ljm_login')->with('success', 'Account created successfully');
    }
}
