<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

class ljm_LogoutController extends Controller
{
    public function ljm_logout(){
     Session::flush();

     Auth::logout();

     return redirect()->to('/ljm_login');
    }
}
