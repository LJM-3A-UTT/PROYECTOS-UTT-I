<?php

use App\Http\Controllers\ljm_RegisterController;
use App\Http\Controllers\ljm_LoginController;
use App\Http\Controllers\ljm_HomeController;
use App\Http\Controllers\ljm_LogoutController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/ljm_register',[ljm_RegisterController::class,'ljm_show']);


Route::post('/ljm_register',[ljm_RegisterController::class,'ljm_register']);

Route::get('/ljm_login',[ljm_LoginController::class,'ljm_show']);

Route::post('/ljm_login',[ljm_LoginController::class,'ljm_login']);

Route::get( '/ljm_home', [ljm_HomeController::class, 'ljm_index']);

Route::get( '/ljm_logout', [ljm_LogoutController::class, 'ljm_logout']);
