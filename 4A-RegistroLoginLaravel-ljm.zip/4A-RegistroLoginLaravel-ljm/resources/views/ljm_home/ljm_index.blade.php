@extends('ljm_layouts.ljm_app-master')

@section('content')

<h1>ljm_Home</h1>

    @auth

    <p>Bienvenido {{auth()->user()->name ?? auth()->user()->username}}, tienes acceso a la pagina como usuario autenticado</p>

    <p><a href="/ljm_logout">Logout</a></p>
    @endauth



    @guest

    <p>
        Bienvenido, Estas en la pagina principal, como invitado no autenticado, tendras acceso

        <br>limitado hasta que sean un usuario verificado

        <a href="/ljm_login">Inicia sesion para tener acceso total</a>

        <br> o <br>

        <a href="/ljm_register">Registrate si es tu primera vez</a>

        para ver todo lo que tenemos que ofrecer
    </p>

    @endguest

@endsection
