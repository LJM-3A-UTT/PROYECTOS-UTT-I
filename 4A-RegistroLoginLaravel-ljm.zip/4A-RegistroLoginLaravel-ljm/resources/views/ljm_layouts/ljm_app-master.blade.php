<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C2-S12-L10-2111-RegistroLoginLaravel</title>
    <link rel="stylesheet" href="{{ url('ljm_assets/css/bootstrap.min.css') }}">
    <!-- Add your custom stylesheets here if needed -->
</head>
<body>
    @include('ljm_layouts.ljm_partials.ljm_navbar')

    <main class="container">
        @yield('content')
    </main>
    <script src="{{ url('ljm_assets/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Add your custom scripts here if needed -->
</body>
</html>
