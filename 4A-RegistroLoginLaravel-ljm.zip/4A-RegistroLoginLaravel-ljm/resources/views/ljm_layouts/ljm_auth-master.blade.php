<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>C2-S12-L10-2111-RegistroLoginLaravel</title>
    <link rel="stylesheet" href="{{ url('ljm_assets/css/bootstrap.min.css') }}">
    <!-- Add your custom stylesheets here if needed -->
    <style>
        body{
            width: 100%;
            height: 100vh;

            display:flex;
            align-items: center;
            justify-content: center;
        }

        .form-container{
           width: 400px;
        }
    </style>

</head>
<body>

    <main class="container">
        @yield('content')
    </main>
    <script src="{{ url('ljm_assets/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Add your custom scripts here if needed -->
</body>
</html>
